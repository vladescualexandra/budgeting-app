package ro.ase.csie.degree.firebase;

public interface Callback<R> {
    void updateUI(R result);
}
